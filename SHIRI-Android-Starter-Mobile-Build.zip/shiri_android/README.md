# SHIRI Store - Android starter

A Persian RTL Android starter app for the SHIRI plumbing-materials shop, built with Kotlin and Jetpack Compose.

## Open and run
1. Install Android Studio (current stable version).
2. Open this folder (`ShiriStore`) in Android Studio.
3. Allow Gradle sync and install the Android SDK 35 if prompted.
4. Run on an Android device or emulator.
5. To create an installable APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Current prototype features
- Blue SHIRI home screen and product categories
- Demo product list and local cart
- Demo admin screen (`admin` is only a displayed label, not authentication)
- Order/payment flow placeholders

## Important before real public launch
This is a UI prototype, not a production commerce system. Product/cart data is currently in memory and resets when the app restarts. It does not yet have a backend, customer accounts, secure admin authentication, order database, delivery workflow, or bank payment gateway. Do not collect real customer or payment information in this prototype. A backend and a payment provider approved for the shop's country must be configured before accepting real orders/payments.
