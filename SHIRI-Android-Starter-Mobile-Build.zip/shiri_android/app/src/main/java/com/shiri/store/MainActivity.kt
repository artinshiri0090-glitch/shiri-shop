package com.shiri.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF087CC1)
private val PaleBlue = Color(0xFFEAF6FD)
private val Ink = Color(0xFF173247)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShiriApp() }
    }
}

data class Product(val id: Int, val name: String, val category: String, val price: String, val stock: Int)

@Composable
fun ShiriApp() {
    var selected by remember { mutableIntStateOf(0) }
    var products by remember {
        mutableStateOf(listOf(
            Product(1, "لوله سفید ۲۰", "لوله‌های سفید", "استعلام قیمت", 24),
            Product(2, "لوله فاضلابی", "لوله‌های فاضلابی", "استعلام قیمت", 15),
            Product(3, "اتصال زانویی سفید", "اتصالات", "استعلام قیمت", 32),
            Product(4, "شیرآلات", "شیرآلات", "استعلام قیمت", 8)
        ))
    }
    val cart = remember { mutableStateListOf<Product>() }
    var notice by remember { mutableStateOf<String?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Color(0xFF36A9E1), background = Color(0xFFF7FBFE))) {
        Scaffold(
            containerColor = Color(0xFFF7FBFE),
            topBar = {
                Column(Modifier.fillMaxWidth().background(Blue).padding(horizontal = 20.dp, vertical = 16.dp)) {
                    Text("SHIRI", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("مصالح لوله‌کشی شیری", color = Color.White, fontSize = 15.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.Store, null) }, label = { Text("محصولات") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = { Icon(Icons.Default.ShoppingCart, null) }, label = { Text("سبد خرید") })
                    NavigationBarItem(selected == 3, { selected = 3 }, icon = { Icon(Icons.Default.AdminPanelSettings, null) }, label = { Text("مدیریت") })
                }
            },
            snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    0 -> HomeScreen(onProducts = { selected = 1 })
                    1 -> ProductsScreen(products, onAdd = { cart.add(it); notice = "به سبد خرید اضافه شد" })
                    2 -> CartScreen(cart, onRemove = { cart.remove(it) }, onCheckout = { notice = "ثبت سفارش در نسخه نمایشی فعال است؛ اتصال سرور در مرحله بعد انجام می‌شود." })
                    else -> AdminScreen(products, onAdd = { name -> products = products + Product((products.maxOfOrNull { it.id } ?: 0) + 1, name, "محصول جدید", "استعلام قیمت", 0); notice = "محصول نمایشی اضافه شد" })
                }
                if (notice != null) {
                    AlertDialog(onDismissRequest = { notice = null }, confirmButton = { TextButton(onClick = { notice = null }) { Text("متوجه شدم") } }, text = { Text(notice!!) })
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onProducts: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Box(Modifier.fillMaxWidth().background(Blue, RoundedCornerShape(24.dp)).padding(22.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("همراه مطمئن ساخت‌وساز", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("انواع لوله، اتصالات و شیرآلات", color = Color.White.copy(alpha = .92f), fontSize = 15.sp)
                Button(onClick = onProducts, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Blue)) { Text("مشاهده محصولات") }
            }
        }
        Text("دسته‌بندی محصولات", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        listOf("لوله‌های سفید", "لوله‌های فاضلابی", "اتصالات", "شیرآلات").forEach { category ->
            Row(Modifier.fillMaxWidth().background(PaleBlue, RoundedCornerShape(14.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WaterDrop, null, tint = Blue)
                Spacer(Modifier.width(12.dp)); Text(category, color = Ink, fontWeight = FontWeight.SemiBold)
            }
        }
        Text("برای اطلاع از قیمت و موجودی، محصول را انتخاب کنید.", color = Color.Gray, fontSize = 13.sp)
    }
}

@Composable
fun ProductsScreen(products: List<Product>, onAdd: (Product) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("محصولات فروشگاه", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products, key = { it.id }) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).background(PaleBlue, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.WaterDrop, null, tint = Blue, modifier = Modifier.size(28.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, color = Ink)
                            Text("${p.category} • موجودی نمونه: ${p.stock}", fontSize = 12.sp, color = Color.Gray)
                            Text(p.price, color = Blue, fontSize = 13.sp)
                        }
                        IconButton(onClick = { onAdd(p) }) { Icon(Icons.Default.AddShoppingCart, "افزودن به سبد", tint = Blue) }
                    }
                }
            }
        }
    }
}

@Composable
fun CartScreen(cart: List<Product>, onRemove: (Product) -> Unit, onCheckout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("سبد خرید", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        if (cart.isEmpty()) Text("سبد خرید شما خالی است.", color = Color.Gray)
        else {
            cart.forEach { p ->
                Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, Modifier.weight(1f), color = Ink)
                    TextButton(onClick = { onRemove(p) }) { Text("حذف") }
                }
            }
            Text("قیمت نهایی پس از تأیید فروشگاه اعلام می‌شود.", fontSize = 12.sp, color = Color.Gray)
            Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth()) { Text("ادامه و ثبت سفارش") }
            Text("روش‌های درنظرگرفته‌شده: پرداخت هنگام تحویل و پرداخت آنلاین (پس از اتصال درگاه).", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun AdminScreen(products: List<Product>, onAdd: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("پنل مدیریت فروشگاه", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("ورود نمایشی مدیر: admin", color = Blue, fontSize = 13.sp)
        Text("این صفحه فعلاً نمونه اولیه است و هنوز به ورود امن و پایگاه داده آنلاین متصل نیست.", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام محصول جدید") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { if (name.isNotBlank()) { onAdd(name.trim()); name = "" } }, modifier = Modifier.fillMaxWidth()) { Text("افزودن محصول نمایشی") }
        Text("تعداد محصولات: ${products.size}", fontWeight = FontWeight.SemiBold, color = Ink)
        Text("مدیریت سفارش‌ها، قیمت و موجودی آنلاین در مرحله اتصال سرور اضافه می‌شود.", fontSize = 13.sp, color = Color.Gray)
    }
}
